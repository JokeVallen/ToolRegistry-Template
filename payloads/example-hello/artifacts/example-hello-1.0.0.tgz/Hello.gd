extends RefCounted

## The smallest possible payload: one file, one function.
##
## A registry tool is whatever you want to share - a helper, an editor extension, a whole
## framework. What makes it a TOOL here is the manifest beside the artifact.

static func greet(name: String) -> String:
	return "Hello, %s." % name
